// Сквозной сценарий через настоящие Edge Functions, PostgREST и Postgres.
// API соцсетей заменены заглушкой. Запуск: см. README, раздел «Тесты».
import { test, before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";
import { createClient } from "@supabase/supabase-js";
import { ANON_KEY, CRON_SECRET, GATEWAY, MOCK_URL, startStack } from "./stack/stack.mjs";

let stack;
const fn = (name, tail = "") => `${GATEWAY}/functions/v1/${name}${tail}`;
let seq = 0;

const mock = {
  calls: async () => (await fetch(`${MOCK_URL}/__calls`)).json(),
  reset: () => fetch(`${MOCK_URL}/__reset`),
  fail: (match, status, body) => fetch(`${MOCK_URL}/__fail`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ match, status, body }),
  }),
};
const sent = async (hostPart, pathPart) =>
  (await mock.calls()).filter((c) => c.host.includes(hostPart) && c.path.includes(pathPart));

function browser() {
  return createClient(GATEWAY, ANON_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
}

async function newOwner(company = "Школа") {
  const client = browser();
  const email = `owner${Date.now()}${++seq}@example.com`;
  const { data, error } = await client.auth.signUp({ email, password: "password123", options: { data: { company } } });
  assert.equal(error, null);
  const { data: member } = await client.from("workspace_members").select("workspace_id").single();
  const { data: survey } = await client.from("surveys").select("*").eq("is_default", true).single();
  return { client, user: data.user, email, workspace: member.workspace_id, survey };
}

async function invoke(client, name, body) {
  const { data, error } = await client.functions.invoke(name, { body });
  if (error) {
    const payload = await error.context.json().catch(() => ({}));
    return { error: payload.error ?? error.message, status: error.context.status };
  }
  return data;
}

async function addQuestions(owner, rows) {
  const payload = rows.map((row, i) => ({ survey_id: owner.survey.id, position: i + 1, options: [], ...row }));
  const { error } = await owner.client.from("questions").insert(payload);
  assert.equal(error, null);
}

const SURVEY = [
  { type: "choice", text: "Когда удобно?", options: [{ id: "sat", label: "Суббота" }, { id: "sun", label: "Воскресенье" }] },
  { type: "text", text: "Как вас зовут?" },
  { type: "phone", text: "Ваш телефон?" },
];

before(async () => {
  stack = await startStack({ postgrestBin: process.env.POSTGREST_BIN });
});
after(async () => {
  await stack.stop();
});
beforeEach(async () => {
  await mock.reset();
  // Заглушка возвращает одни и те же аккаунты, поэтому каждый тест начинает без подключённых каналов.
  await stack.db.query("update channels set deleted_at = now() where deleted_at is null");
});

const metaSign = (secret, raw) => `sha256=${crypto.createHmac("sha256", secret).update(raw).digest("hex")}`;
const metaPost = (raw, signature) => fetch(fn("webhook", "/meta"), {
  method: "POST",
  headers: { "content-type": "application/json", ...(signature ? { "x-hub-signature-256": signature } : {}) },
  body: raw,
});

async function secretOf(channelId) {
  return (await stack.db.query("select * from channel_secrets where channel_id = $1", [channelId])).rows[0];
}

test("Telegram-бот: подключение, опрос, заявка на сайте, ответ администратора", async () => {
  const owner = await newOwner();
  await addQuestions(owner, SURVEY);

  const bad = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "telegram", token: "BAD" });
  assert.match(bad.error, /не принял токен/);

  const TOKEN = `123:TELEGRAM-${Date.now()}`;
  const { channel, setup, warning } = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "telegram", token: TOKEN });
  assert.equal(channel.status, "active");
  assert.equal(channel.name, "Школа бот");
  assert.equal(setup, null);
  assert.equal(warning, null);
  assert.equal(channel.token_hint, `••••${TOKEN.slice(-4)}`);

  const [hook] = await sent("telegram", "setWebhook");
  assert.equal(hook.body.url, `${GATEWAY}/functions/v1/webhook/${channel.id}`);
  assert.deepEqual(hook.body.allowed_updates, ["message", "callback_query", "business_connection", "business_message"]);

  // Токен в базе зашифрован, браузер его не получает.
  const secret = await secretOf(channel.id);
  assert.ok(!JSON.stringify(secret).includes(TOKEN));
  assert.equal(hook.body.secret_token, secret.webhook_secret);
  const { data: visible, error: secretErr } = await owner.client.from("channel_secrets").select("*");
  assert.ok(secretErr || visible.length === 0);

  const post = (update, header = secret.webhook_secret) => fetch(fn("webhook", `/${channel.id}`), {
    method: "POST",
    headers: { "content-type": "application/json", ...(header ? { "x-telegram-bot-api-secret-token": header } : {}) },
    body: JSON.stringify(update),
  });
  const from = { id: 5001, first_name: "Анна", last_name: "К", username: "anna" };
  const message = (id, text) => ({ update_id: id, message: { message_id: id, from, chat: { id: 5001, type: "private" }, date: 1, text } });

  assert.equal((await post(message(1, "привет"), "wrong")).status, 401);
  assert.equal((await post(message(1, "привет"), null)).status, 401);
  assert.equal((await sent("telegram", "sendMessage")).length, 0);

  assert.equal((await post(message(1, "привет"))).status, 200);
  let out = await sent("telegram", "sendMessage");
  assert.equal(out.length, 2);
  assert.match(out[0].body.text, /Здравствуйте/);
  assert.equal(out[1].body.text, "Когда удобно?");
  assert.deepEqual(out[1].body.reply_markup.inline_keyboard, [
    [{ text: "Суббота", callback_data: "o:sat" }],
    [{ text: "Воскресенье", callback_data: "o:sun" }],
  ]);

  // Повторная доставка того же сообщения ничего не отправляет.
  await post(message(1, "привет"));
  assert.equal((await sent("telegram", "sendMessage")).length, 2);

  // Групповой чат бот игнорирует.
  await post({ update_id: 9, message: { message_id: 9, from, chat: { id: -100, type: "group" }, text: "всем привет" } });
  assert.equal((await sent("telegram", "sendMessage")).length, 2);

  await post({ update_id: 2, callback_query: { id: "cb-1", from, data: "o:sun", message: { message_id: 1002, chat: { id: 5001, type: "private" } } } });
  assert.equal((await sent("telegram", "answerCallbackQuery")).length, 1);
  assert.equal((await sent("telegram", "editMessageReplyMarkup"))[0].body.message_id, 1002);
  out = await sent("telegram", "sendMessage");
  assert.equal(out.at(-1).body.text, "Как вас зовут?");

  await post(message(3, "Анна"));
  await post(message(4, "телефон не дам"));
  out = await sent("telegram", "sendMessage");
  assert.match(out.at(-1).body.text, /ошибка/);
  await post(message(5, "+998901234567"));
  out = await sent("telegram", "sendMessage");
  assert.match(out.at(-1).body.text, /Спасибо/);

  // То, что видит администратор на сайте.
  const { data: leads } = await owner.client.from("leads").select("*, contacts(*), answers(*), messages(*)");
  assert.equal(leads.length, 1);
  const lead = leads[0];
  assert.equal(lead.status, "new");
  assert.equal(lead.contacts.display_name, "Анна К");
  assert.equal(lead.contacts.username, "anna");
  assert.equal(lead.contacts.phone, "+998901234567");
  assert.deepEqual(lead.answers.sort((a, b) => a.position - b.position).map((a) => a.answer_text), ["Воскресенье", "Анна", "+998901234567"]);
  assert.ok(lead.messages.every((m) => m.status !== "queued" && m.status !== "failed"));

  const { error: takeError } = await owner.client.rpc("take_lead", { p_lead_id: lead.id });
  assert.equal(takeError, null);

  await mock.reset();
  const reply = await invoke(owner.client, "send-message", { lead_id: lead.id, text: "Записал вас на воскресенье!" });
  assert.equal(reply.ok, true);
  [out] = [await sent("telegram", "sendMessage")];
  assert.equal(out[0].body.chat_id, "5001");
  assert.equal(out[0].body.text, "Записал вас на воскресенье!");

  // Чужой пользователь ни прочитать заявку, ни написать в неё не может.
  const stranger = await newOwner("Чужая школа");
  const { data: noLeads } = await stranger.client.from("leads").select("id");
  assert.deepEqual(noLeads, []);
  const denied = await invoke(stranger.client, "send-message", { lead_id: lead.id, text: "спам" });
  assert.equal(denied.status, 404);
  const deniedCheck = await invoke(stranger.client, "channels", { action: "check", channel_id: channel.id });
  assert.equal(deniedCheck.status, 403);
  const deniedConnect = await invoke(stranger.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "telegram", token: "1:x" });
  assert.equal(deniedConnect.status, 403);
  const stolen = await invoke(stranger.client, "channels", { action: "connect", workspace_id: stranger.workspace, platform: "telegram", token: "1:x" });
  assert.match(stolen.error, /другом кабинете/);

  // Без входа функции недоступны.
  const anonymous = await fetch(fn("channels"), { method: "POST", body: "{}" });
  assert.equal(anonymous.status, 401);

  // Отключение: webhook снимается, история остаётся.
  const off = await invoke(owner.client, "channels", { action: "disconnect", channel_id: channel.id });
  assert.equal(off.ok, true);
  assert.equal((await sent("telegram", "deleteWebhook")).length, 1);
  assert.equal((await post(message(6, "ещё"))).status, 404);
  assert.equal(await secretOf(channel.id), undefined);
  const { data: kept } = await owner.client.from("leads").select("id");
  assert.equal(kept.length, 1);
});

test("Telegram Business: ответ от личного аккаунта, сообщение владельца останавливает бота", async () => {
  const owner = await newOwner();
  await addQuestions(owner, SURVEY);
  const { channel } = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "telegram", token: "123:BUSINESS" });
  const secret = await secretOf(channel.id);
  const post = (update) => fetch(fn("webhook", `/${channel.id}`), {
    method: "POST",
    headers: { "content-type": "application/json", "x-telegram-bot-api-secret-token": secret.webhook_secret },
    body: JSON.stringify(update),
  });
  const customer = { id: 6001, first_name: "Клиент" };
  const ownerUser = { id: 42, first_name: "Владелец" };
  const chat = { id: 6001, type: "private" };

  await post({ update_id: 1, business_message: { business_connection_id: "bc-1", message_id: 1, from: customer, chat, text: "Здравствуйте" } });
  let out = await sent("telegram", "sendMessage");
  assert.equal(out.length, 2);
  assert.ok(out.every((c) => c.body.business_connection_id === "bc-1"));
  assert.ok(out[1].body.reply_markup.inline_keyboard, "только inline-кнопки: обычная клавиатура в Business не работает");

  // Кнопка в бизнес-чате.
  await post({ update_id: 2, callback_query: { id: "cb-2", from: customer, data: "o:sat", message: { message_id: 50, business_connection_id: "bc-1", chat } } });
  out = await sent("telegram", "sendMessage");
  assert.equal(out.at(-1).body.text, "Как вас зовут?");
  assert.equal(out.at(-1).body.business_connection_id, "bc-1");
  assert.equal((await sent("telegram", "editMessageReplyMarkup"))[0].body.business_connection_id, "bc-1");

  // Своё сообщение бота, пришедшее обратно, ни на что не влияет.
  await post({ update_id: 3, business_message: { business_connection_id: "bc-1", message_id: 3, from: ownerUser, chat, sender_business_bot: { id: 777001 }, text: "Как вас зовут?" } });
  const { data: stillCollecting } = await owner.client.from("leads").select("status").single();
  assert.equal(stillCollecting.status, "collecting");

  // Владелец написал сам: бот останавливается, реплика видна на сайте.
  const before = (await sent("telegram", "sendMessage")).length;
  await post({ update_id: 4, business_message: { business_connection_id: "bc-1", message_id: 4, from: ownerUser, chat, text: "Добрый день, это Анна, подскажу лично" } });
  const { data: lead } = await owner.client.from("leads").select("status, messages(sender, text)").single();
  assert.equal(lead.status, "in_work");
  assert.ok(lead.messages.some((m) => m.sender === "agent" && m.text.includes("это Анна")));

  await post({ update_id: 5, business_message: { business_connection_id: "bc-1", message_id: 5, from: customer, chat, text: "Спасибо" } });
  assert.equal((await sent("telegram", "sendMessage")).length, before);
});

test("Instagram: настройка webhook, подпись, кнопки, эхо, длинные варианты, продление токена", async () => {
  const owner = await newOwner();
  await addQuestions(owner, [
    { type: "choice", text: "Когда удобно?", options: [{ id: "a", label: "Суббота" }, { id: "b", label: "Воскресенье" }] },
    { type: "choice", text: "Какой филиал?", options: [{ id: "c", label: "Чиланзар, улица Катартал, дом 5" }, { id: "d", label: "Юнусабад" }] },
    { type: "text", text: "Как вас зовут?" },
  ]);

  const noSecret = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "instagram", token: "IG" });
  assert.match(noSecret.error, /App Secret/);
  const badToken = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "instagram", token: "BAD", app_secret: "s" });
  assert.match(badToken.error, /недействителен/);

  const APP_SECRET = "ig-app-secret";
  const res = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "instagram", token: "IG-LONG-TOKEN-1234", app_secret: APP_SECRET });
  assert.equal(res.channel.external_id, "17841400000000001", "используем user_id, он приходит в webhook как entry.id");
  assert.equal(res.channel.name, "@school_uz");
  assert.equal(res.channel.status, "pending");
  assert.ok(res.channel.token_expires_at);
  assert.equal(res.setup.callback_url, `${GATEWAY}/functions/v1/webhook/meta`);
  const [subscribe] = await sent("instagram", "subscribed_apps");
  assert.equal(subscribe.query.subscribed_fields, "messages,messaging_postbacks");

  const again = await invoke(owner.client, "channels", { action: "setup", channel_id: res.channel.id });
  assert.equal(again.setup.verify_token, res.setup.verify_token);

  // Проверка адреса со стороны Meta.
  const verify = (token) => fetch(fn("webhook", `/meta?hub.mode=subscribe&hub.challenge=1158201444&hub.verify_token=${token}`));
  const good = await verify(res.setup.verify_token);
  assert.equal(good.status, 200);
  assert.equal(await good.text(), "1158201444");
  assert.equal((await verify("wrong")).status, 403);

  const event = (messaging) => JSON.stringify({ object: "instagram", entry: [{ id: "17841400000000001", time: 1, messaging: [messaging] }] });
  const incoming = (mid, message) => ({ sender: { id: "igsid-1" }, recipient: { id: "17841400000000001" }, timestamp: 1, message: { mid, ...message } });

  const raw = event(incoming("m1", { text: "Привет" }));
  assert.equal((await metaPost(raw)).status, 401);
  assert.equal((await metaPost(raw, metaSign("wrong-secret", raw))).status, 401);
  assert.equal((await sent("instagram", "me/messages")).length, 0);
  const { data: errored } = await owner.client.from("channels").select("last_error").single();
  assert.match(errored.last_error, /App Secret/);

  assert.equal((await metaPost(raw, metaSign(APP_SECRET, raw))).status, 200);
  let out = await sent("instagram", "me/messages");
  assert.equal(out.length, 2);
  assert.equal(out[1].body.recipient.id, "igsid-1");
  assert.deepEqual(out[1].body.message.quick_replies, [
    { content_type: "text", title: "Суббота", payload: "o:a" },
    { content_type: "text", title: "Воскресенье", payload: "o:b" },
  ]);

  // Статус канала стал рабочим, ошибка настройки исчезла вместе с первым событием.
  const { data: live } = await owner.client.from("channels").select("status, last_event_at, last_error").single();
  assert.equal(live.status, "active");
  assert.ok(live.last_event_at);
  assert.equal(live.last_error, null);

  // Повторная проверка не сбрасывает рабочий канал обратно в ожидание.
  const rechecked = await invoke(owner.client, "channels", { action: "check", channel_id: res.channel.id });
  assert.equal(rechecked.channel.status, "active");
  await mock.reset();

  // Имя подтянулось из профиля.
  const { data: contact } = await owner.client.from("contacts").select("display_name, username").single();
  assert.deepEqual(contact, { display_name: "Анна Клиент", username: "anna_client" });

  // Эхо своего сообщения: бот не должен ответить сам себе.
  const echoRaw = event({ sender: { id: "17841400000000001" }, recipient: { id: "igsid-1" }, message: { mid: "echo", text: "Когда удобно?", is_echo: true } });
  await metaPost(echoRaw, metaSign(APP_SECRET, echoRaw));
  const echoRaw2 = event({ sender: { id: "igsid-1" }, recipient: { id: "17841400000000001" }, message: { mid: "echo2", text: "x", is_echo: true } });
  await metaPost(echoRaw2, metaSign(APP_SECRET, echoRaw2));
  // Отметка о прочтении не является сообщением.
  const readRaw = event({ sender: { id: "igsid-1" }, recipient: { id: "17841400000000001" }, read: { mid: "m1" } });
  await metaPost(readRaw, metaSign(APP_SECRET, readRaw));
  assert.equal((await sent("instagram", "me/messages")).length, 0, "после сброса заглушки бот ничего не отправил");

  const quick = event(incoming("m2", { text: "Суббота", quick_reply: { payload: "o:a" } }));
  await metaPost(quick, metaSign(APP_SECRET, quick));
  out = await sent("instagram", "me/messages");
  // Подпись длиннее 20 символов: варианты в тексте, на кнопках номера.
  assert.match(out.at(-1).body.message.text, /1\. Чиланзар, улица Катартал, дом 5/);
  assert.deepEqual(out.at(-1).body.message.quick_replies.map((q) => [q.title, q.payload]), [["1", "o:c"], ["2", "o:d"]]);

  // Клиент отвечает цифрой.
  const typed = event(incoming("m3", { text: "1" }));
  await metaPost(typed, metaSign(APP_SECRET, typed));
  out = await sent("instagram", "me/messages");
  assert.equal(out.at(-1).body.message.text, "Как вас зовут?");

  // Ошибка платформы при отправке видна на сайте, а Meta получает 200 и не повторяет webhook.
  await mock.fail("me/messages", 400, { error: { code: 10, error_subcode: 2534022, message: "outside window" } });
  const failing = event(incoming("m4", { text: "Анна" }));
  assert.equal((await metaPost(failing, metaSign(APP_SECRET, failing))).status, 200);
  const { data: failed } = await owner.client.from("messages").select("status, error").eq("status", "failed");
  assert.equal(failed.length, 1);
  assert.match(failed[0].error, /24 часов/);
  const { data: noChannelError } = await owner.client.from("channels").select("last_error").single();
  assert.equal(noChannelError.last_error, null, "окно 24 часа касается одного клиента, а не канала");

  // Истёкший токен виден на карточке канала, успешная отправка снимает ошибку.
  await mock.reset();
  await mock.fail("me/messages", 400, { error: { code: 190, message: "Token expired" } });
  const { data: leadRow } = await owner.client.from("leads").select("id").single();
  await invoke(owner.client, "send-message", { lead_id: leadRow.id, text: "Проверка" });
  const { data: tokenError } = await owner.client.from("channels").select("last_error").single();
  assert.match(tokenError.last_error, /истёк/);
  await mock.reset();
  await invoke(owner.client, "send-message", { lead_id: leadRow.id, text: "Проверка 2" });
  const { data: cleared } = await owner.client.from("channels").select("last_error").single();
  assert.equal(cleared.last_error, null);

  // Продление токена: только с секретом и только скоро истекающие.
  await stack.db.query("update channels set token_expires_at = now() + interval '5 days' where id = $1", [res.channel.id]);
  assert.equal((await fetch(fn("refresh-tokens"), { method: "POST" })).status, 401);
  const refresh = await fetch(fn("refresh-tokens"), { method: "POST", headers: { "x-cron-secret": CRON_SECRET } });
  assert.equal(refresh.status, 200);
  const { refreshed } = await refresh.json();
  assert.ok(refreshed.some((r) => r.id === res.channel.id && r.ok));
  const { data: renewed } = await owner.client.from("channels").select("token_hint, token_expires_at").single();
  assert.equal(renewed.token_hint, "••••9999");
  assert.ok(new Date(renewed.token_expires_at) > new Date(Date.now() + 50 * 86400000));

  // Новый токен реально используется при отправке.
  const after = event(incoming("m5", { text: "ещё сообщение" }));
  await metaPost(after, metaSign(APP_SECRET, after));
  const { data: lead } = await owner.client.from("leads").select("id").single();
  await invoke(owner.client, "send-message", { lead_id: lead.id, text: "Ответ" });
  out = await sent("instagram", "me/messages");
  assert.equal(out.at(-1).query.access_token, "IG-REFRESHED-9999");
});

test("Facebook Messenger: страница, кнопка, ответ", async () => {
  const owner = await newOwner();
  await addQuestions(owner, SURVEY);
  const APP_SECRET = "fb-secret";
  const res = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "facebook", token: "PAGE-TOKEN", app_secret: APP_SECRET });
  assert.equal(res.channel.external_id, "1000000000000001");
  assert.ok(res.setup.verify_token);

  const event = (message) => JSON.stringify({ object: "page", entry: [{ id: "1000000000000001", time: 1, messaging: [{ sender: { id: "psid-1" }, recipient: { id: "1000000000000001" }, timestamp: 1, message }] }] });
  const hi = event({ mid: "fb1", text: "Здравствуйте" });
  assert.equal((await metaPost(hi, metaSign(APP_SECRET, hi))).status, 200);
  let out = await sent("facebook", "me/messages");
  assert.equal(out.length, 2);
  assert.equal(out[1].body.messaging_type, "RESPONSE");

  const quick = event({ mid: "fb2", text: "Воскресенье", quick_reply: { payload: "o:sun" } });
  await metaPost(quick, metaSign(APP_SECRET, quick));
  out = await sent("facebook", "me/messages");
  assert.equal(out.at(-1).body.message.text, "Как вас зовут?");
  const { data: contact } = await owner.client.from("contacts").select("display_name").single();
  assert.equal(contact.display_name, "Борис Клиент");
  const { data: answer } = await owner.client.from("answers").select("answer_text").single();
  assert.equal(answer.answer_text, "Воскресенье");
});

test("WhatsApp: кнопки до 3, список до 10, ответы кнопкой, статусы игнорируются", async () => {
  const owner = await newOwner();
  await addQuestions(owner, [
    SURVEY[0],
    { type: "choice", text: "Какой курс?", options: [{ id: "a", label: "Английский" }, { id: "b", label: "Немецкий" }, { id: "c", label: "Корейский" }, { id: "d", label: "Французский" }] },
    { type: "text", text: "Как вас зовут?" },
  ]);
  const APP_SECRET = "wa-secret";
  const missing = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "whatsapp", token: "WA", app_secret: APP_SECRET });
  assert.match(missing.error, /Phone number ID/);
  const res = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "whatsapp", token: "WA-TOKEN", app_secret: APP_SECRET, phone_number_id: "109000000000001", waba_id: "2000000000001" });
  assert.equal(res.channel.external_id, "109000000000001");
  assert.equal((await sent("facebook", "2000000000001/subscribed_apps")).length, 1);

  const event = (value) => JSON.stringify({
    object: "whatsapp_business_account",
    entry: [{ id: "2000000000001", changes: [{ field: "messages", value: { messaging_product: "whatsapp", metadata: { display_phone_number: "998900000000", phone_number_id: "109000000000001" }, ...value } }] }],
  });
  const contact = { contacts: [{ profile: { name: "Вали" }, wa_id: "998901112233" }] };
  const hi = event({ ...contact, messages: [{ from: "998901112233", id: "wamid.1", timestamp: "1", type: "text", text: { body: "Салом" } }] });
  await metaPost(hi, metaSign(APP_SECRET, hi));
  let out = await sent("facebook", "109000000000001/messages");
  assert.equal(out.length, 2);
  assert.equal(out[0].body.type, "text");
  assert.equal(out[1].body.interactive.type, "button");
  assert.deepEqual(out[1].body.interactive.action.buttons[0], { type: "reply", reply: { id: "o:sat", title: "Суббота" } });

  const status = event({ statuses: [{ id: "wamid.x", status: "read", recipient_id: "998901112233" }] });
  assert.equal((await metaPost(status, metaSign(APP_SECRET, status))).status, 200);

  const tap = event({ ...contact, messages: [{ from: "998901112233", id: "wamid.2", timestamp: "2", type: "interactive", interactive: { type: "button_reply", button_reply: { id: "o:sun", title: "Воскресенье" } } }] });
  await metaPost(tap, metaSign(APP_SECRET, tap));
  out = await sent("facebook", "109000000000001/messages");
  assert.equal(out.length, 3);
  assert.equal(out[2].body.interactive.type, "list");
  assert.equal(out[2].body.interactive.action.sections[0].rows.length, 4);

  const pick = event({ ...contact, messages: [{ from: "998901112233", id: "wamid.3", timestamp: "3", type: "interactive", interactive: { type: "list_reply", list_reply: { id: "o:c", title: "Корейский" } } }] });
  await metaPost(pick, metaSign(APP_SECRET, pick));
  out = await sent("facebook", "109000000000001/messages");
  assert.equal(out.at(-1).body.text.body, "Как вас зовут?");

  const { data: lead } = await owner.client.from("leads").select("answers(answer_text), contacts(display_name)").single();
  assert.deepEqual(lead.answers.map((a) => a.answer_text).sort(), ["Воскресенье", "Корейский"]);
  assert.equal(lead.contacts.display_name, "Вали");
});

test("Viber: подпись, приветствие до подписки, клавиатура", async () => {
  const owner = await newOwner();
  await addQuestions(owner, SURVEY);
  const TOKEN = "viber-token-1";
  const { channel } = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "viber", token: TOKEN });
  assert.equal(channel.status, "active");
  const [hook] = await sent("viber", "set_webhook");
  assert.equal(hook.body.url, `${GATEWAY}/functions/v1/webhook/${channel.id}`);
  assert.equal(hook.headers["x-viber-auth-token"], TOKEN);

  const post = (body, token = TOKEN) => {
    const raw = JSON.stringify(body);
    return fetch(fn("webhook", `/${channel.id}`), {
      method: "POST",
      headers: { "content-type": "application/json", "x-viber-content-signature": crypto.createHmac("sha256", token).update(raw).digest("hex") },
      body: raw,
    });
  };
  assert.equal((await post({ event: "webhook", timestamp: 1 })).status, 200);
  const started = await post({ event: "conversation_started", user: { id: "v1", name: "Вика" } });
  assert.match((await started.json()).text, /Здравствуйте/);

  const hi = { event: "message", timestamp: 1, message_token: 111, sender: { id: "v1", name: "Вика" }, message: { type: "text", text: "Привет" } };
  assert.equal((await post(hi, "forged")).status, 401);
  assert.equal((await post(hi)).status, 200);
  let out = await sent("viber", "send_message");
  assert.equal(out.length, 2);
  assert.equal(out[1].body.receiver, "v1");
  assert.equal(out[1].body.keyboard.Buttons[1].ActionBody, "Воскресенье");
  assert.equal(out[1].body.sender.name, "Школа Viber");

  await post({ ...hi, message_token: 112, message: { type: "text", text: "Воскресенье" } });
  out = await sent("viber", "send_message");
  assert.equal(out.at(-1).body.text, "Как вас зовут?");
  assert.equal(out.at(-1).body.keyboard, undefined);

  await post({ ...hi, message_token: 113, message: { type: "picture", media: "http://x" } });
  out = await sent("viber", "send_message");
  assert.match(out.at(-1).body.text, /понимаю только текст/);
  await post({ event: "delivered", message_token: 114, user_id: "v1" });
  assert.equal((await sent("viber", "send_message")).length, out.length);
});

test("VK: подтверждение сервера, секрет, клавиатура с payload, беседы игнорируются", async () => {
  const owner = await newOwner();
  await addQuestions(owner, SURVEY);
  const { channel } = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "vk", token: "vk-token" });
  assert.equal(channel.external_id, "555000");
  assert.equal(channel.status, "active");

  const calls = await mock.calls();
  const order = calls.map((c) => c.path.split("/").pop());
  assert.ok(order.indexOf("groups.getCallbackConfirmationCode") < order.indexOf("groups.addCallbackServer"), "код подтверждения сохраняется раньше добавления сервера");
  const settings = calls.find((c) => c.path.endsWith("groups.setCallbackSettings"));
  assert.equal(settings.body.message_new, "1");
  assert.equal(settings.body.server_id, "7");
  const secret = await secretOf(channel.id);
  assert.equal(calls.find((c) => c.path.endsWith("groups.addCallbackServer")).body.secret_key, secret.webhook_secret);

  const post = (body) => fetch(fn("webhook", `/${channel.id}`), { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  const confirm = await post({ type: "confirmation", group_id: 555000 });
  assert.equal(await confirm.text(), "vk-confirm-abc");
  assert.equal((await post({ type: "confirmation", group_id: 1 })).status, 401);

  const message = (id, extra) => ({
    type: "message_new", group_id: 555000, event_id: `e${id}`, v: "5.199", secret: secret.webhook_secret,
    object: { message: { id, from_id: 9001, peer_id: 9001, date: 1, ...extra }, client_info: {} },
  });
  assert.equal((await post({ ...message(1, { text: "Привет" }), secret: "wrong" })).status, 401);
  const res = await post(message(1, { text: "Привет" }));
  assert.equal(await res.text(), "ok", "VK требует ответ ok");
  let out = await sent("vk", "messages.send");
  assert.equal(out.length, 2);
  const keyboard = JSON.parse(out[1].body.keyboard);
  assert.equal(keyboard.buttons[0][0].action.label, "Суббота");
  assert.equal(keyboard.buttons[1][0].action.payload, JSON.stringify({ o: "sun" }));

  await post(message(2, { text: "Воскресенье", payload: JSON.stringify({ o: "sun" }) }));
  out = await sent("vk", "messages.send");
  assert.equal(out.at(-1).body.message, "Как вас зовут?");
  const { data: answer } = await owner.client.from("answers").select("option_id").single();
  assert.equal(answer.option_id, "sun");

  // Сообщение из беседы не запускает опрос.
  await post({ ...message(3, { text: "всем" }), object: { message: { id: 3, from_id: 9002, peer_id: 2000000001, text: "всем" } } });
  assert.equal((await sent("vk", "messages.send")).length, out.length);

  const { data: contact } = await owner.client.from("contacts").select("display_name").single();
  assert.equal(contact.display_name, "Вера Клиент");
});

test("Канал с ошибкой токена помечается, повторное подключение обновляет токен и сохраняет адрес", async () => {
  const owner = await newOwner();
  const first = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "viber", token: "t1" });
  const secret1 = await secretOf(first.channel.id);
  await mock.fail("set_webhook", 200, { status: 1, status_message: "invalidUrl" });
  const failed = await invoke(owner.client, "channels", { action: "check", channel_id: first.channel.id });
  assert.match(failed.error, /invalidUrl/);
  const { data: broken } = await owner.client.from("channels").select("status, last_error").single();
  assert.equal(broken.status, "error");
  assert.match(broken.last_error, /invalidUrl/);

  // Токен отозван: «Проверить» показывает ошибку на карточке.
  await mock.reset();
  await mock.fail("get_account_info", 200, { status: 2, status_message: "invalidAuthToken" });
  const revoked = await invoke(owner.client, "channels", { action: "check", channel_id: first.channel.id });
  assert.match(revoked.error, /не принял токен/);
  const { data: revokedRow } = await owner.client.from("channels").select("status, last_error").single();
  assert.equal(revokedRow.status, "error");
  assert.match(revokedRow.last_error, /не принял токен/);

  await mock.reset();
  const second = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "viber", token: "t2-new" });
  assert.equal(second.channel.id, first.channel.id);
  assert.equal(second.channel.status, "active");
  assert.equal(second.channel.last_error, null);
  assert.equal(second.channel.token_hint, "••••-new");
  const secret2 = await secretOf(first.channel.id);
  assert.equal(secret2.webhook_secret, secret1.webhook_secret);
  assert.notEqual(secret2.token_enc, secret1.token_enc);
  await invoke(owner.client, "channels", { action: "disconnect", channel_id: first.channel.id });
});

test("Команда: владелец добавляет и удаляет администратора, администратор работает с заявками", async () => {
  const owner = await newOwner();
  await addQuestions(owner, SURVEY);
  const email = `admin${Date.now()}@example.com`;

  assert.match((await invoke(owner.client, "team", { action: "add", workspace_id: owner.workspace, email, password: "123" })).error, /8 символов/);
  assert.equal((await invoke(owner.client, "team", { action: "add", workspace_id: owner.workspace, email, password: "password123" })).ok, true);
  assert.match((await invoke(owner.client, "team", { action: "add", workspace_id: owner.workspace, email, password: "password123" })).error, /уже зарегистрирован/);

  const admin = browser();
  const { error: loginError, data: login } = await admin.auth.signInWithPassword({ email, password: "password123" });
  assert.equal(loginError, null);

  const { data: members } = await admin.from("workspace_members").select("role, email");
  assert.equal(members.length, 2);
  assert.equal(members.find((m) => m.email === email).role, "admin");

  // Администратор не трогает каналы, команду и вопросы.
  const noChannel = await invoke(admin, "channels", { action: "connect", workspace_id: owner.workspace, platform: "telegram", token: "1:x" });
  assert.equal(noChannel.status, 403);
  assert.equal((await invoke(admin, "team", { action: "add", workspace_id: owner.workspace, email: "x@example.com", password: "password123" })).status, 403);
  const { error: noQuestion } = await admin.from("questions").insert({ survey_id: owner.survey.id, text: "x" });
  assert.ok(noQuestion);

  // Заявки ему доступны.
  const { channel } = await invoke(owner.client, "channels", { action: "connect", workspace_id: owner.workspace, platform: "telegram", token: "123:TEAM" });
  const secret = await secretOf(channel.id);
  await fetch(fn("webhook", `/${channel.id}`), {
    method: "POST",
    headers: { "content-type": "application/json", "x-telegram-bot-api-secret-token": secret.webhook_secret },
    body: JSON.stringify({ update_id: 1, message: { message_id: 1, from: { id: 7 }, chat: { id: 7, type: "private" }, text: "hi" } }),
  });
  const { data: lead } = await admin.from("leads").select("id").single();
  assert.equal((await admin.rpc("take_lead", { p_lead_id: lead.id })).error, null);
  assert.equal((await invoke(admin, "send-message", { lead_id: lead.id, text: "Здравствуйте" })).ok, true);
  const taken = await owner.client.rpc("take_lead", { p_lead_id: lead.id });
  assert.match(taken.error.message, new RegExp(email));

  // После удаления вход и данные закрыты, история заявки на месте.
  assert.match((await invoke(owner.client, "team", { action: "remove", workspace_id: owner.workspace, user_id: owner.user.id })).error, /Владельца/);
  assert.equal((await invoke(owner.client, "team", { action: "remove", workspace_id: owner.workspace, user_id: login.user.id })).ok, true);
  const { rows } = await stack.db.query("select 1 from auth.users where email = $1", [email]);
  assert.equal(rows.length, 0);
  const { data: messages } = await owner.client.from("messages").select("text").eq("sender", "agent");
  assert.equal(messages[0].text, "Здравствуйте");
  await invoke(owner.client, "channels", { action: "disconnect", channel_id: channel.id });
});
