import type { Lead, LeadStatus } from "./types";

const timeFormat = new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" });
const dayFormat = new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short" });
const fullFormat = new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });

export function shortTime(value: string): string {
  const date = new Date(value);
  return date.toDateString() === new Date().toDateString() ? timeFormat.format(date) : dayFormat.format(date);
}

export const fullTime = (value: string) => fullFormat.format(new Date(value));

export const STATUS_LABEL: Record<LeadStatus, string> = {
  collecting: "Бот опрашивает",
  new: "Новая",
  in_work: "В работе",
  done: "Завершена",
  rejected: "Отказ",
};

export function contactName(lead: Pick<Lead, "contacts">): string {
  const c = lead.contacts;
  return c?.display_name || (c?.username ? `@${c.username}` : "") || c?.phone || "Без имени";
}

/** Значение для CSV. Текст клиента, начинающийся с =, + или @, Excel выполнил бы как формулу. */
export function csvCell(value: unknown): string {
  let text = value === null || value === undefined ? "" : String(value);
  if (/^[=+\-@\t\r]/.test(text) && !/^\+?\d+$/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}
