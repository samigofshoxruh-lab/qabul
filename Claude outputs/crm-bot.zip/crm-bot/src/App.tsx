import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { Navigate, NavLink, Route, Routes } from "react-router-dom";
import type { Session } from "@supabase/supabase-js";
import { Inbox, ListChecks, LogOut, Plug, Users } from "lucide-react";
import { isConfigured, supabase } from "./lib/supabase";
import type { Workspace } from "./lib/types";
import { AuthPage } from "./pages/AuthPage";
import { ChannelsPage } from "./pages/ChannelsPage";
import { LeadsPage } from "./pages/LeadsPage";
import { SurveysPage } from "./pages/SurveysPage";
import { TeamPage } from "./pages/TeamPage";

interface AppContextValue {
  workspace: Workspace;
  userId: string;
  reloadWorkspace: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function useApp(): AppContextValue {
  const value = useContext(AppContext);
  if (!value) throw new Error("Нет контекста приложения");
  return value;
}

function NotConfigured() {
  return (
    <main className="center-screen">
      <div className="center-box">
        <h1>Подключите Supabase</h1>
        <p>
          Создайте файл <code>.env</code> по образцу <code>.env.example</code>, укажите адрес проекта и publishable key, затем
          перезапустите сайт.
        </p>
      </div>
    </main>
  );
}

function Shell({ workspace, children }: { workspace: Workspace; children: React.ReactNode }) {
  const isOwner = workspace.role === "owner";
  return (
    <div className="shell">
      <nav className="rail" aria-label="Разделы">
        <span className="logo" aria-hidden title="Отклик">
          <span />
        </span>
        <NavLink to="/" end className="rail-link">
          <Inbox size={22} aria-hidden /> Заявки
        </NavLink>
        {isOwner && (
          <NavLink to="/questions" className="rail-link">
            <ListChecks size={22} aria-hidden /> Вопросы
          </NavLink>
        )}
        {isOwner && (
          <NavLink to="/channels" className="rail-link">
            <Plug size={22} aria-hidden /> Каналы
          </NavLink>
        )}
        <NavLink to="/team" className="rail-link">
          <Users size={22} aria-hidden /> Команда
        </NavLink>
        <button type="button" className="rail-link rail-exit" onClick={() => supabase.auth.signOut()}>
          <LogOut size={22} aria-hidden /> Выйти
        </button>
      </nav>
      <div className="stage">{children}</div>
    </div>
  );
}

export function App() {
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [workspace, setWorkspace] = useState<Workspace | null | undefined>(undefined);

  useEffect(() => {
    if (!isConfigured) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => data.subscription.unsubscribe();
  }, []);

  const userId = session?.user.id;

  const loadWorkspace = useCallback(async () => {
    if (!userId) {
      setWorkspace(undefined);
      return;
    }
    const { data, error } = await supabase
      .from("workspace_members")
      .select("role, workspaces(id, name)")
      .eq("user_id", userId)
      .limit(1)
      .maybeSingle();
    if (error || !data) {
      setWorkspace(null);
      return;
    }
    const ws = data.workspaces as unknown as { id: string; name: string };
    setWorkspace({ id: ws.id, name: ws.name, role: data.role as Workspace["role"] });
  }, [userId]);

  useEffect(() => {
    loadWorkspace();
  }, [loadWorkspace]);

  if (!isConfigured) return <NotConfigured />;
  if (session === undefined) return <main className="center-screen" aria-busy="true" />;
  if (!session) return <AuthPage />;
  if (workspace === undefined) return <main className="center-screen" aria-busy="true" />;
  if (workspace === null) {
    return (
      <main className="center-screen">
        <div className="center-box">
          <h1>Кабинет не найден</h1>
          <p>Этот аккаунт не состоит ни в одном кабинете. Попросите владельца добавить вас заново.</p>
          <button type="button" className="button" onClick={() => supabase.auth.signOut()}>
            Выйти
          </button>
        </div>
      </main>
    );
  }

  const isOwner = workspace.role === "owner";
  return (
    <AppContext.Provider value={{ workspace, userId: session.user.id, reloadWorkspace: loadWorkspace }}>
      <Shell workspace={workspace}>
        <Routes>
          <Route path="/" element={<LeadsPage />} />
          <Route path="/leads/:leadId" element={<LeadsPage />} />
          <Route path="/questions" element={isOwner ? <SurveysPage /> : <Navigate to="/" replace />} />
          <Route path="/channels" element={isOwner ? <ChannelsPage /> : <Navigate to="/" replace />} />
          <Route path="/team" element={<TeamPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Shell>
    </AppContext.Provider>
  );
}
