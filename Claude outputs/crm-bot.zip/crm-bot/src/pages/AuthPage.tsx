import { useState, type FormEvent } from "react";
import { errorText, supabase } from "../lib/supabase";
import { ErrorNote } from "../components/ui";

const SAMPLE = [
  { q: "Какой курс вас интересует?", a: "Английский язык" },
  { q: "Когда удобно прийти на первое занятие?", a: "Суббота, 10:00" },
  { q: "Как вас зовут?", a: "Мадина" },
  { q: "Номер телефона", a: "+998 90 123 45 67" },
];

const AUTH_ERRORS: Record<string, string> = {
  invalid_credentials: "Неверный email или пароль.",
  user_already_exists: "Этот email уже зарегистрирован. Войдите в аккаунт.",
  weak_password: "Пароль слишком простой. Используйте не меньше 8 символов.",
  email_not_confirmed: "Подтвердите email: ссылка отправлена на почту.",
  signup_disabled: "Регистрация закрыта. Попросите владельца добавить вас в команду.",
};

export function AuthPage() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [company, setCompany] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    setInfo("");
    try {
      if (mode === "login") {
        const { error: e } = await supabase.auth.signInWithPassword({ email, password });
        if (e) throw e;
      } else {
        const { data, error: e } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { company: company.trim() } },
        });
        if (e) throw e;
        if (!data.session) setInfo("Письмо с подтверждением отправлено. Перейдите по ссылке и войдите.");
      }
    } catch (e) {
      const code = (e as { code?: string }).code;
      setError((code && AUTH_ERRORS[code]) || errorText(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth">
      <section className="auth-intro">
        <p className="brand">Отклик</p>
        <h1>Клиент пишет «привет», а вы получаете готовую анкету</h1>
        <p className="auth-lead">
          Бот сам задаёт ваши вопросы в Telegram, Instagram, Facebook, WhatsApp, Viber и ВКонтакте. Ответы сразу появляются на сайте, и
          администратор берёт заявку в работу.
        </p>
        <dl className="sheet sheet-sample" aria-label="Пример заполненной анкеты">
          {SAMPLE.map((row) => (
            <div className="sheet-row" key={row.q}>
              <dt>{row.q}</dt>
              <dd>
                <mark>{row.a}</mark>
              </dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="auth-form-wrap">
        <form className="form auth-form" onSubmit={submit}>
          <h2>{mode === "login" ? "Вход" : "Новый кабинет"}</h2>
          {mode === "signup" && (
            <label className="field">
              Название компании
              <input value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Например, учебный центр «Зиё»" maxLength={120} required />
            </label>
          )}
          <label className="field">
            Email
            <input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>
          <label className="field">
            Пароль
            <input
              type="password"
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              minLength={mode === "signup" ? 8 : undefined}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </label>
          <ErrorNote>{error}</ErrorNote>
          {info && <p className="note" role="status">{info}</p>}
          <button className="button button-primary" disabled={busy}>
            {mode === "login" ? "Войти" : "Создать кабинет"}
          </button>
          <button
            type="button"
            className="link-button"
            onClick={() => {
              setMode(mode === "login" ? "signup" : "login");
              setError("");
              setInfo("");
            }}
          >
            {mode === "login" ? "Создать новый кабинет" : "У меня уже есть аккаунт"}
          </button>
        </form>
      </section>
    </main>
  );
}
