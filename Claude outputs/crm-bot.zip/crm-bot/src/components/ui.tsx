import { useEffect, useRef, type ReactNode } from "react";
import { AlertTriangle, X } from "lucide-react";
import { PLATFORMS } from "../lib/platforms";
import type { Platform } from "../lib/types";

export function ChannelTag({ platform }: { platform: Platform }) {
  const info = PLATFORMS[platform];
  return (
    <span className="tag" style={{ color: info.color, borderColor: info.color }} title={info.label} aria-label={info.label}>
      {info.code}
    </span>
  );
}

export function ErrorNote({ children }: { children: ReactNode }) {
  if (!children) return null;
  return (
    <p className="note note-error" role="alert">
      <AlertTriangle size={16} aria-hidden /> <span>{children}</span>
    </p>
  );
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = ref.current;
    if (dialog && !dialog.open) dialog.showModal();
  }, []);
  return (
    <dialog ref={ref} className="modal" onCancel={onClose} onClose={onClose} aria-label={title}>
      <header className="modal-head">
        <h2>{title}</h2>
        <button type="button" className="icon-button" onClick={onClose} aria-label="Закрыть">
          <X size={20} aria-hidden />
        </button>
      </header>
      <div className="modal-body">{children}</div>
    </dialog>
  );
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="empty">
      <h3>{title}</h3>
      {children}
    </div>
  );
}
